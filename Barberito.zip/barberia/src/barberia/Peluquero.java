/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package barberia;

/**
 *
 * @author johan
 */
public class Peluquero extends Persona{
    private int[] cosPel={8000,10500,40000,15000};//coete caballerro,corte dama,tintura,peinado
    private int canCor=0,canTotCor=0;
    private double cosTotPel,cosTotCor;
    
    public void calCosPel(int i){
        cosTotCor=cosPel[i]*canCor;//Calcula el costo del corte
        cosTotPel+=cosTotCor;
        canTotCor+=canCor;
    }

    public void setCanCor(int canCor) {
        this.canCor = canCor;
    }

    public int getCanCor() {
        return canCor;
    }

    public int getCanTotCor() {
        return canTotCor;
    }

    public double getCosTotPel() {
        return cosTotPel;
    }

    public double getCosTotCor() {
        return cosTotCor;
    }

    public void setCanTotCor(int canTotCor) {
        this.canTotCor = canTotCor;
    }

    public void setCosTotPel(double cosTotPel) {
        this.cosTotPel = cosTotPel;
    }

    public void setCosTotCor(double cosTotCor) {
        this.cosTotCor = cosTotCor;
    }
}
